package com.example.vedanandConstruction.VedanandConstruction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VedanandConstructionApplicationTests {

	@Test
	void contextLoads() {
	}

}
