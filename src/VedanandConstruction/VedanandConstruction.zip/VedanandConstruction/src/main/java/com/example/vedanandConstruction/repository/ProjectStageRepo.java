package com.example.vedanandConstruction.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.vedanandConstruction.entity.ProjectStages;

public interface ProjectStageRepo extends JpaRepository<ProjectStages,Integer>{

}
